import React from 'react'
import './Background.css'

const Background = () => {
  return (
    <div className="background-container">
    {/* <text className="background-text">Get to know me by <br/>
    Blowing Up the Bubbles </text> */}
  </div>
  )
}

export default Background